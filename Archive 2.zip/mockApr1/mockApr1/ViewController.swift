//
//  ViewController.swift
//  mockApr1
//
//  Created by Aaron Levy on 4/1/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var visitedLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        NotificationCenter.default.addObserver(self, selector: #selector(visited), name: NSNotification.Name(rawValue: "iVisited"), object: nil)
    }

    @IBAction func Next(_ sender: UIButton) {
        navigationController?.pushViewController(UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailViewController"), animated: true)
        
    }
    
    @objc func visited(){
        visitedLbl.text = "You visited DetailViewController"
    }
    
}

