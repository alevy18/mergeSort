//
//  DetailViewController.swift
//  mockApr1
//
//  Created by Aaron Levy on 4/1/21.
//

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func back(_ sender: UIButton) {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "iVisited"), object: nil, userInfo: nil)
        
        navigationController?.popToRootViewController(animated: true)
        
    }
    

}
