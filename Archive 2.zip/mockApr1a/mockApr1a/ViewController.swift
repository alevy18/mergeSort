//
//  ViewController.swift
//  mockApr1a
//
//  Created by Aaron Levy on 4/1/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    
    
    
    @IBOutlet weak var tbl: UITableView!
    
    var movArr = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tbl.delegate = self
        tbl.dataSource = self
        
        let path = Bundle.main.path(forResource: "movies", ofType: "plist")
        let movArr = NSArray.init(contentsOfFile: path!) as! [String]
        print(movArr)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1")
        cell?.textLabel?.text = movArr[indexPath.row]
        
        return cell!
    }

    


}

