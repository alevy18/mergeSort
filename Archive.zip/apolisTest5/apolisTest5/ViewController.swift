//
//  ViewController.swift
//  apolisTest5
//
//  Created by Aaron Levy on 3/26/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let button = UIButton.init(type: .plain, primaryAction: <#T##UIAction?#>)
        
    }


}

