//
//  Smart.swift
//  ToDoList
//
//  Created by Aaron Levy on 4/7/21.
//

import UIKit

class SmartSegmentControl: UISegmentedControl {
    
    var model: Any?
    

}
