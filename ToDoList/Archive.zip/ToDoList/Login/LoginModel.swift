//
//  LoginModel.swift
//  ToDoList
//
//  Created by Aaron Levy on 4/6/21.
//

import Foundation

struct login {
    var username: String?
    var password: String?
}
